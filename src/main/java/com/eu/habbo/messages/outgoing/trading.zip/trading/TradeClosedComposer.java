package com.eu.habbo.messages.outgoing.trading;

import com.eu.habbo.messages.ServerMessage;
import com.eu.habbo.messages.outgoing.MessageComposer;
import com.eu.habbo.messages.outgoing.Outgoing;

/**
 * Created on 8-11-2014 13:37.
 */
public class TradeClosedComposer extends MessageComposer
{
    public static final int USER_CANCEL_TRADE = 0;
    public static final int ITEMS_NOT_FOUND = 1;

    private final int userId;
    private final int errorCode;

    public TradeClosedComposer(int userId, int errorCode)
    {
        this.userId = userId;
        this.errorCode = errorCode;
    }

    @Override
    public ServerMessage compose()
    {
        this.response.init(Outgoing.TradeStoppedComposer);
        this.response.appendInt32(this.userId);
        this.response.appendInt32(this.errorCode);
        return this.response;
    }
}
