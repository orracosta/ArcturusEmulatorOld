package com.eu.habbo.messages.incoming.friends;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.messenger.Messenger;
import com.eu.habbo.habbohotel.users.Habbo;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.friends.FriendRequestComposer;
import com.eu.habbo.messages.outgoing.friends.FriendRequestErrorComposer;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created on 25-8-2014 18:11.
 */
public class FriendRequestEvent extends MessageHandler {

    @Override
    public void handle() throws Exception {
        String username = packet.readString();
        Habbo habbo = Emulator.getServer().getGameClientManager().getHabbo(username);

        int id = 0;
        boolean allowFriendRequests = true;

        if(habbo == null)
        {
            try
            {
                PreparedStatement statement = Emulator.getDatabase().prepare("SELECT users_settings.block_friendrequests, users.id FROM users INNER JOIN users_settings ON users.id = users_settings.user_id WHERE username = ? LIMIT 1");
                statement.setString(1, username);
                ResultSet set = statement.executeQuery();
                while(set.next())
                {
                    id = set.getInt("id");
                    allowFriendRequests = set.getString("block_friendrequests").equalsIgnoreCase("0");
                }
                set.close();
                statement.close();
            } catch (SQLException e)
            {
                Emulator.getLogging().logSQLException(e);
                return;
            }
        }
        else
        {
            id = habbo.getHabboInfo().getId();
            allowFriendRequests = !habbo.getHabboStats().blockFriendRequests;
            if(allowFriendRequests)
                Emulator.getServer().getGameClientManager().getClient(habbo).sendResponse(new FriendRequestComposer(this.client.getHabbo()));
        }

        if(id != 0)
        {
            if(!allowFriendRequests)
            {
                this.client.sendResponse(new FriendRequestErrorComposer(FriendRequestErrorComposer.TARGET_NOT_ACCEPTING_REQUESTS));
                return;
            }

            if(this.client.getHabbo().getMessenger().getFriends().values().size() >= Emulator.getConfig().getInt("hotel.max.friends"))
            {
                this.client.sendResponse(new FriendRequestErrorComposer(FriendRequestErrorComposer.FRIEND_LIST_OWN_FULL));
                return;
            }
                Messenger.makeFriendRequest(this.client.getHabbo().getHabboInfo().getId(), id);
        }
        else
        {
            this.client.sendResponse(new FriendRequestErrorComposer(FriendRequestErrorComposer.TARGET_NOT_FOUND));
        }
    }
}
