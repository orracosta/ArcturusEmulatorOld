package com.eu.habbo.messages.incoming.handshake;

import com.eu.habbo.messages.incoming.MessageHandler;

/**
 * Created on 24-8-2014 17:20.
 */
public class MachineIDEvent extends MessageHandler {

    @Override
    public void handle() throws Exception {
        //TODO: Save user machine ID.
    }
}
