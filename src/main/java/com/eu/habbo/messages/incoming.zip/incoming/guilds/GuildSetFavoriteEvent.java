package com.eu.habbo.messages.incoming.guilds;

import com.eu.habbo.messages.incoming.MessageHandler;

/**
 * Created on 29-11-2014 13:18.
 */
public class GuildSetFavoriteEvent extends MessageHandler
{
    @Override
    public void handle() throws Exception
    {
        int guildId = this.packet.readInt();

        if(this.client.getHabbo().getHabboStats().hasGuild(guildId))
        {
            this.client.getHabbo().getHabboStats().guild = guildId;
        }
    }
}
