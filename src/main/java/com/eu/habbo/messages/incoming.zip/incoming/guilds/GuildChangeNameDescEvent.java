package com.eu.habbo.messages.incoming.guilds;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.guilds.Guild;
import com.eu.habbo.habbohotel.guilds.GuildMember;
import com.eu.habbo.habbohotel.rooms.Room;
import com.eu.habbo.habbohotel.users.Habbo;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.guilds.GuildInfoComposer;
import gnu.trove.set.hash.THashSet;

/**
 * Created on 23-11-2014 12:19.
 */
public class GuildChangeNameDescEvent extends MessageHandler
{
    @Override
    public void handle() throws Exception
    {
        int guildId = this.packet.readInt();

        Guild guild = Emulator.getGameEnvironment().getGuildManager().getGuild(guildId);

        if(guild == null || guild.getOwnerId() != this.client.getHabbo().getHabboInfo().getId()) //TODO: Allow staff
            return;

        String newName = this.packet.readString();
        String newDescription = this.packet.readString();

        if(guild.getName().equals(newName) && guild.getDescription().equals(newDescription))
            return;

        guild.setName(newName);
        guild.setDescription(newDescription);
        guild.needsUpdate = true;
        guild.run();

        Room room = Emulator.getGameEnvironment().getRoomManager().getRoom(guild.getRoomId());

        if(room != null && room.getUserCount() > 0)
        {
            THashSet<GuildMember> admins = Emulator.getGameEnvironment().getGuildManager().getOnlyAdmins(guild);

            boolean found = false;
            for(Habbo habbo : room.getCurrentHabbos().valueCollection())
            {
                if(habbo.getHabboStats().hasGuild(guildId))
                {
                    for (GuildMember member : admins)
                    {
                        if (member.getUserId() == habbo.getHabboInfo().getId())
                        {
                            habbo.getClient().sendResponse(new GuildInfoComposer(guild, habbo.getClient(), false, member));
                            found = true;
                            break;
                        }
                    }

                    if (!found)
                    {
                        habbo.getClient().sendResponse(new GuildInfoComposer(guild, habbo.getClient(), false, Emulator.getGameEnvironment().getGuildManager().getGuildMember(guild, habbo)));
                        found = false;
                    }
                }
                else
                {
                    habbo.getClient().sendResponse(new GuildInfoComposer(guild, habbo.getClient(), false, null));
                }
            }
        }
    }
}
