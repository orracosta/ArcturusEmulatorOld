package com.eu.habbo.messages.incoming.users;

import com.eu.habbo.Emulator;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.friends.MessengerInitComposer;
import com.eu.habbo.messages.outgoing.friends.UpdateFriendComposer;
import com.eu.habbo.messages.outgoing.generic.alerts.GenericAlertComposer;
import com.eu.habbo.messages.outgoing.generic.FavoriteRoomsCountComposer;
import com.eu.habbo.messages.outgoing.generic.MinimailCountComposer;
import com.eu.habbo.messages.outgoing.handshake.DebugConsoleComposer;
import com.eu.habbo.messages.outgoing.hotelview.HallOfFameComposer;
import com.eu.habbo.messages.outgoing.modtool.ModToolComposer;
import com.eu.habbo.messages.outgoing.users.*;
import com.eu.habbo.messages.outgoing.handshake.SessionRightsComposer;

/**
 * Created on 24-8-2014 17:36.
 */
public class RequestUserDataEvent extends MessageHandler {

    @Override
    public void handle() throws Exception {

        if (this.client.getHabbo() != null) {
            this.client.sendResponse(new DebugConsoleComposer());
            this.client.sendResponse(new UserHomeRoomComposer());
            this.client.sendResponse(new MinimailCountComposer());
            this.client.sendResponse(new UserPermissionsComposer(this.client.getHabbo()));
            this.client.sendResponse(new SessionRightsComposer());
            this.client.sendResponse(new UserCurrencyComposer(this.client.getHabbo()));
            this.client.sendResponse(new UserDataComposer(this.client.getHabbo()));
            this.client.sendResponse(new UserPerksComposer());
            this.client.sendResponse(new FavoriteRoomsCountComposer());
            this.client.sendResponse(new UserBCLimitsComposer());
            this.client.sendResponse(new HallOfFameComposer());
            this.client.sendResponse(new UpdateFriendComposer(Emulator.publicChatBuddy));
            this.client.sendResponse(new UserAchievementScoreComposer(this.client.getHabbo()));
            this.client.sendResponse(new GenericAlertComposer(Emulator.getTexts().getValue("hotel.alert.message.welcome").replace("%user%", this.client.getHabbo().getHabboInfo().getUsername()), this.client.getHabbo()));
            this.client.sendResponse(new UserClothesComposer());
            this.client.sendResponse(new MessengerInitComposer());

            if(this.client.getHabbo().hasPermission("acc_supporttool"))
            {
                this.client.sendResponse(new ModToolComposer());
            }
        }
        else
        {
            this.client.dispose();
        }
    }
}
