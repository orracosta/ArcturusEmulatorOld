package com.eu.habbo.messages.incoming.guilds;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.guilds.Guild;
import com.eu.habbo.habbohotel.rooms.Room;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.catalog.PurchaseOKComposer;
import com.eu.habbo.messages.outgoing.guilds.GuildBoughtComposer;
import com.eu.habbo.messages.outgoing.users.UserCreditsComposer;

import java.util.List;

/**
 * Created on 22-11-2014 18:27.
 */
public class RequestGuildBuyEvent extends MessageHandler
{
    @Override
    public void handle() throws Exception
    {
        this.client.getHabbo().getHabboInfo().addCredits(-10);
        this.client.sendResponse(new UserCreditsComposer(this.client.getHabbo()));

        String name = this.packet.readString();
        String description = this.packet.readString();

        int roomId = this.packet.readInt();

        Room r = null;
        List<Room> rooms = Emulator.getGameEnvironment().getRoomManager().getRoomsForHabbo(this.client.getHabbo());
        for(Room room : rooms)
        {
            if (room.getId() == roomId)
            {
                r = room;
                break;
            }
        }

        if(r != null)
        {
            if(r.getGuildId() == 0)
            {
                int colorOne = this.packet.readInt();
                int colorTwo = this.packet.readInt();

                int count = this.packet.readInt() / 3;

                int a = this.packet.readInt();
                int b = this.packet.readInt();
                int c = this.packet.readInt();

                String[] badgeData = new String[count];
                badgeData[0] = "b" + (a < 10 ? "0" + a : a) + (b < 10 ? "0" + b : b) + c;

                for (int i = 1; i < count; i++)
                {
                    int j = this.packet.readInt();
                    int k = this.packet.readInt();
                    int l = this.packet.readInt();

                    badgeData[i] = "s" + (j < 10 ? "0" + j : j) + (k < 10 ? "0" + k : k) + l;
                }

                String badge = "";
                for (int i = 0; i < badgeData.length; i++)
                {
                    if (badgeData[i].equals("s000") || badgeData[i].equals("s00000"))
                    {
                        badgeData[i] = "";
                    }
                    badge += badgeData[i];
                }

                Guild guild = Emulator.getGameEnvironment().getGuildManager().createGuild(this.client.getHabbo(), roomId, name, description, badge, colorOne, colorTwo);
                r.setGuild(guild.getId());
                r.setNeedsUpdate(true);
                this.client.sendResponse(new PurchaseOKComposer());
                this.client.sendResponse(new GuildBoughtComposer(guild));

                Emulator.getGameEnvironment().getGuildManager().addGuild(guild);
            }
        }
    }
}
