package com.eu.habbo.messages.incoming.rooms;

import com.eu.habbo.habbohotel.rooms.Room;
import com.eu.habbo.habbohotel.rooms.RoomState;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.rooms.*;

/**
 * Created on 22-10-2014 16:38.
 */
public class RoomSettingsSaveEvent extends MessageHandler
{
    @Override
    public void handle() throws Exception
    {
        int roomId = this.packet.readInt();

        Room room = this.client.getHabbo().getHabboInfo().getCurrentRoom();

        if(room.getId() == roomId)
        {
            if(room.getOwnerId() == this.client.getHabbo().getHabboInfo().getId() || this.client.getHabbo().hasPermission("acc_anyroomowner"))
            {
                room.setName(this.packet.readString());
                room.setDescription(this.packet.readString());
                room.setState(RoomState.values()[this.packet.readInt() % RoomState.values().length]);
                room.setPassword(this.packet.readString());
                room.setUsersMax(this.packet.readInt());
                room.setCategory(this.packet.readInt());

                String tags = "";
                int count = this.packet.readInt();
                for(int i = 0; i < count; i++)
                {
                    tags += this.packet.readString() + ";";
                }

                room.setTags(tags);
                this.packet.readInt(); //Trade Mode
                room.setAllowPets(this.packet.readBoolean());
                room.setAllowPetsEat(this.packet.readBoolean());
                room.setAllowWalkthrough(this.packet.readBoolean());
                room.setHideWall(this.packet.readBoolean());
                room.setWallSize(this.packet.readInt());
                room.setFloorSize(this.packet.readInt());
                room.setMuteOption(this.packet.readInt());
                room.setKickOption(this.packet.readInt());
                room.setBanOption(this.packet.readInt());
                room.setChatMode(this.packet.readInt());
                room.setChatWeight(this.packet.readInt());
                room.setChatSpeed(this.packet.readInt());
                room.setChatDistance(Math.abs(this.packet.readInt()));
                room.setChatProtection(this.packet.readInt());
                room.setNeedsUpdate(true);

                room.sendComposer(new RoomThicknessComposer(room).compose());
                room.sendComposer(new RoomChatSettingsComposer(room).compose());
                room.sendComposer(new RoomSettingsUpdatedComposer(room).compose());
                this.client.sendResponse(new RoomSettingsSavedComposer(room));
                //TODO Find packet for update room name.
            }
        }
    }
}
