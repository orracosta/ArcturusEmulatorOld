package com.eu.habbo.messages.incoming.guilds;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.guilds.Guild;
import com.eu.habbo.messages.incoming.MessageHandler;

/**
 * Created on 23-11-2014 14:39.
 */
public class GuildChangeSettingsEvent extends MessageHandler
{
    @Override
    public void handle() throws Exception
    {
        int guildId = this.packet.readInt();

        Guild guild = Emulator.getGameEnvironment().getGuildManager().getGuild(guildId);
        guild.setState(this.packet.readInt());
        guild.setRights(this.packet.readInt());
        guild.needsUpdate = true;

        if(this.client.getHabbo().getHabboInfo().getCurrentRoom() != null)
        {
            if(this.client.getHabbo().getHabboInfo().getCurrentRoom().getId() == guild.getRoomId())
            {
                this.client.getHabbo().getHabboInfo().getCurrentRoom().refreshGuildRightsInRoom();
            }
        }

        Emulator.getThreading().run(guild);
    }
}
