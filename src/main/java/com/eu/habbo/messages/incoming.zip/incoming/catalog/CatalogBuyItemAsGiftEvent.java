package com.eu.habbo.messages.incoming.catalog;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.catalog.CatalogItem;
import com.eu.habbo.habbohotel.catalog.CatalogPage;
import com.eu.habbo.habbohotel.items.Item;
import com.eu.habbo.habbohotel.items.interactions.*;
import com.eu.habbo.habbohotel.users.Habbo;
import com.eu.habbo.habbohotel.users.HabboItem;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.catalog.AlertLimitedSoldOutComposer;
import com.eu.habbo.messages.outgoing.catalog.AlertPurchaseFailedComposer;
import com.eu.habbo.messages.outgoing.catalog.PurchaseOKComposer;
import com.eu.habbo.messages.outgoing.generic.alerts.GenericAlertComposer;
import com.eu.habbo.messages.outgoing.inventory.AddHabboItemComposer;
import com.eu.habbo.messages.outgoing.inventory.InventoryRefreshComposer;
import com.eu.habbo.messages.outgoing.users.UserCreditsComposer;
import com.eu.habbo.messages.outgoing.users.UserUpdateCurrencyComposer;
import gnu.trove.set.hash.THashSet;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;

/**
 * Created on 22-1-2015 20:45.
 */
public class CatalogBuyItemAsGiftEvent extends MessageHandler
{
    @Override
    public void handle() throws Exception
    {
        int pageId = this.packet.readInt();
        int itemId = this.packet.readInt();
        String extraData = this.packet.readString();
        String username = this.packet.readString();
        String message = this.packet.readString();
        int spriteId = this.packet.readInt();
        int color = this.packet.readInt();
        int ribbonId = this.packet.readInt();
        boolean showName = this.packet.readBoolean();

        int count = 1;
        int userId = 0;

        if(!Emulator.getGameEnvironment().getCatalogManager().giftWrappers.containsKey(spriteId))
        {
            this.client.sendResponse(new AlertPurchaseFailedComposer(AlertPurchaseFailedComposer.SERVER_ERROR).compose());
        }

        Item giftItem = Emulator.getGameEnvironment().getItemManager().getItem(Emulator.getGameEnvironment().getCatalogManager().giftWrappers.get(spriteId));

        if(giftItem == null)
        {
            this.client.sendResponse(new AlertPurchaseFailedComposer(AlertPurchaseFailedComposer.SERVER_ERROR).compose());
            return;
        }

        Habbo habbo = Emulator.getGameEnvironment().getHabboManager().getHabbo(username);

        if(habbo == null)
        {
            try
            {
                PreparedStatement s = Emulator.getDatabase().prepare("SELECT id FROM users WHERE username = ?");
                s.setString(1, username);

                ResultSet set = s.executeQuery();

                if (set.next())
                {
                    userId = set.getInt(1);
                }

                set.close();
                s.close();
            } catch (SQLException e)
            {
                Emulator.getLogging().logSQLException(e);
            }
        }
        else
        {
            userId = habbo.getHabboInfo().getId();
        }

        if(userId == 0)
        {
            this.client.sendResponse(new AlertPurchaseFailedComposer(AlertPurchaseFailedComposer.SERVER_ERROR).compose());
            return;
        }

        CatalogPage page = Emulator.getGameEnvironment().getCatalogManager().catalogPages.get(pageId);

        if(page == null)
        {
            this.client.sendResponse(new AlertPurchaseFailedComposer(AlertPurchaseFailedComposer.SERVER_ERROR).compose());
            return;
        }

        CatalogItem item = page.getCatalogItem(itemId);
        Item cBaseItem = null;

        if(item == null)
        {
            this.client.sendResponse(new AlertPurchaseFailedComposer(AlertPurchaseFailedComposer.SERVER_ERROR).compose());
            return;
        }

        try
        {
            if (item.isLimited())
            {
                if (item.getLimitedSells() == item.getLimitedStack())
                {
                    this.client.sendResponse(new AlertLimitedSoldOutComposer());
                    return;
                }
                item.sellRare();
            }

            int totalCredits = 0;
            int totalPoints = 0;

            THashSet<HabboItem> itemsList = new THashSet<HabboItem>();

            for(int i = 0; i < count; i++)
            {
                if (item.getCredits() <= this.client.getHabbo().getHabboInfo().getCredits() - totalCredits)
                {
                    if(
                            item.getPointsType() == 0 && item.getPoints() <= this.client.getHabbo().getHabboInfo().getPixels() - totalPoints ||
                                    item.getPoints() <= this.client.getHabbo().getHabboInfo().getPoints())
                    {
                        if ((i + 1) % 6 != 0 && item.isHaveOffer())
                        {
                            totalCredits += item.getCredits();
                            totalPoints += item.getPoints();
                        }

                        for (int j = 0; j < item.getAmount(); j++)
                        {
                            for (Item baseItem : item.getBaseItems())
                            {
                                for(int k = 0; k < item.getItemAmount(baseItem.getId()); k++)
                                {
                                    cBaseItem = baseItem;
                                    if (!baseItem.getName().contains("avatar_effect"))
                                    {
                                        if(item.getName().startsWith("rentable_bot_"))
                                        {
                                            this.client.sendResponse(new AlertPurchaseFailedComposer(AlertPurchaseFailedComposer.SERVER_ERROR).compose());
                                            return;
                                        }
                                        else if(Item.isPet(baseItem))
                                        {
                                            this.client.sendResponse(new AlertPurchaseFailedComposer(AlertPurchaseFailedComposer.SERVER_ERROR).compose());
                                            return;
                                        }
                                        else
                                        {
                                            if (baseItem.getInteractionType().getType() == InteractionTrophy.class || baseItem.getInteractionType().getType() == InteractionBadgeDisplay.class)
                                            {
                                                extraData = this.client.getHabbo().getHabboInfo().getUsername() + (char) 9 + Calendar.getInstance().get(Calendar.DAY_OF_MONTH) + "-" + (Calendar.getInstance().get(Calendar.MONTH) + 1) + "-" + Calendar.getInstance().get(Calendar.YEAR) + (char) 9 + extraData;
                                            }

                                            if (baseItem.getInteractionType().getType() == InteractionTeleport.class)
                                            {
                                                HabboItem teleportOne = Emulator.getGameEnvironment().getItemManager().createItem(0, baseItem, item.getLimitedStack(), item.getLimitedSells(), extraData);
                                                HabboItem teleportTwo = Emulator.getGameEnvironment().getItemManager().createItem(0, baseItem, item.getLimitedStack(), item.getLimitedSells(), extraData);
                                                Emulator.getGameEnvironment().getItemManager().insertTeleportPair(teleportOne.getId(), teleportTwo.getId());
                                                itemsList.add(teleportOne);
                                                itemsList.add(teleportTwo);
                                            }
                                            else if(baseItem.getInteractionType().getType() == InteractionHopper.class)
                                            {
                                                HabboItem hopper = Emulator.getGameEnvironment().getItemManager().createItem(0, baseItem, item.getLimitedSells(), item.getLimitedSells(), extraData);

                                                Emulator.getGameEnvironment().getItemManager().insertHopper(hopper);

                                                itemsList.add(hopper);
                                            }
                                            else if(baseItem.getInteractionType().getType() == InteractionGuildFurni.class || baseItem.getInteractionType().getType() == InteractionGuildGate.class)
                                            {
                                                InteractionGuildFurni habboItem = (InteractionGuildFurni)Emulator.getGameEnvironment().getItemManager().createItem(0, baseItem, item.getLimitedStack(), item.getLimitedSells(), extraData);
                                                habboItem.setExtradata("");
                                                habboItem.needsUpdate(true);
                                                int guildId;
                                                try
                                                {
                                                    guildId = Integer.parseInt(extraData);
                                                }
                                                catch (Exception e)
                                                {
                                                    Emulator.getLogging().logErrorLine(e);
                                                    this.client.sendResponse(new AlertPurchaseFailedComposer(AlertPurchaseFailedComposer.SERVER_ERROR));
                                                    return;
                                                }
                                                Emulator.getThreading().run(habboItem);
                                                Emulator.getGameEnvironment().getGuildManager().setGuild(habboItem, guildId);
                                                itemsList.add(habboItem);
                                            }
                                            else
                                            {
                                                HabboItem habboItem = Emulator.getGameEnvironment().getItemManager().createItem(0, baseItem, item.getLimitedStack(), item.getLimitedSells(), extraData);
                                                itemsList.add(habboItem);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        this.client.sendResponse(new AlertPurchaseFailedComposer(AlertPurchaseFailedComposer.SERVER_ERROR));
                                        this.client.sendResponse(new GenericAlertComposer(Emulator.getTexts().getValue("error.catalog.buy.not_yet")));
                                        return;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            String giftData = itemsList.size() + "\t";

            for(HabboItem i : itemsList)
            {
                giftData += i.getId() + "\t";
            }

            giftData += color + "\t" + ribbonId + "\t" + (showName ? "1" : "0") + "\t" + (message.replace("\t", "")) + "\t" + this.client.getHabbo().getHabboInfo().getUsername() + "\t" + this.client.getHabbo().getHabboInfo().getLook();

            HabboItem gift = Emulator.getGameEnvironment().getItemManager().createGift(username, giftItem, giftData, 0, 0);

            if(gift == null)
            {
                this.client.sendResponse(new AlertPurchaseFailedComposer(AlertPurchaseFailedComposer.SERVER_ERROR));
                return;
            }

            if(habbo != null)
            {
                habbo.getClient().sendResponse(new AddHabboItemComposer(gift));
                habbo.getClient().getHabbo().getHabboInventory().getItemsComponent().addItem(gift);
                habbo.getClient().sendResponse(new InventoryRefreshComposer());
            }

            if(!this.client.getHabbo().hasPermission("acc_infinite_credits"))
            {
                if (totalCredits > 0)
                {
                    this.client.getHabbo().getHabboInfo().addCredits(-totalCredits);
                    this.client.sendResponse(new UserCreditsComposer(this.client.getHabbo()));
                }
            }
            if(totalPoints > 0)
            {
                if(item.getPointsType() == 0 && !this.client.getHabbo().hasPermission("acc_infinite_pixels")) {
                    this.client.getHabbo().getHabboInfo().addPixels(-totalPoints);
                    this.client.sendResponse(new UserUpdateCurrencyComposer(this.client.getHabbo().getHabboInfo().getPixels(), -totalPoints, 0));
                }else if(item.getPointsType() == 105 && !this.client.getHabbo().hasPermission("acc_infinite_points")) {
                    this.client.getHabbo().getHabboInfo().addPoints(-totalPoints);
                    this.client.sendResponse(new UserUpdateCurrencyComposer(this.client.getHabbo().getHabboInfo().getPoints(), -totalPoints, 105));
                }
            }

            this.client.sendResponse(new PurchaseOKComposer(item, cBaseItem));

        }
        catch(Exception e)
        {
            Emulator.getLogging().logPacketError(e);
            this.client.sendResponse(new AlertPurchaseFailedComposer(AlertPurchaseFailedComposer.SERVER_ERROR));
            return;
        }
    }
}
