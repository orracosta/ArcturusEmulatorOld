package com.eu.habbo.messages.incoming.friends;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.messenger.Message;
import com.eu.habbo.habbohotel.messenger.MessengerBuddy;
import com.eu.habbo.habbohotel.users.Habbo;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.friends.FriendChatMessageComposer;

/**
 * Created on 26-8-2014 10:45.
 */
public class FriendPrivateMessageEvent extends MessageHandler {

    @Override
    public void handle() throws Exception {
        int userId = this.packet.readInt();
        String message = this.packet.readString();

        MessengerBuddy buddy = this.client.getHabbo().getMessenger().getFriend(userId);

        if(buddy == null) {
            Emulator.getServer().getGameClientManager().sendBroadcastResponse(new FriendChatMessageComposer(new Message(0, 0, this.client.getHabbo().getHabboInfo().getUsername() + ": " + message)).compose(), this.client);
            return;
        }

        Habbo habbo = Emulator.getServer().getGameClientManager().getHabbo(userId);

        if(habbo == null)
            return;

        Message chatMessage = new Message(this.client.getHabbo().getHabboInfo().getId(), userId, message);
        Emulator.getServer().getGameClientManager().getClient(habbo).sendResponse(new FriendChatMessageComposer(chatMessage));
    }
}
