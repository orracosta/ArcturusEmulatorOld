package com.eu.habbo.messages.incoming.modtool;

import com.eu.habbo.messages.incoming.MessageHandler;

/**
 * Created on 4-11-2014 13:29.
 */
public class ModToolRequestRoomChatlogEvent extends MessageHandler
{
    @Override
    public void handle() throws Exception
    {
        if(this.client.getHabbo().hasPermission("acc_supporttool"))
        {

        }
    }
}
