package com.eu.habbo.messages.incoming.rooms.items;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.items.interactions.InteractionStackHelper;
import com.eu.habbo.habbohotel.rooms.Room;
import com.eu.habbo.habbohotel.rooms.RoomUnit;
import com.eu.habbo.habbohotel.users.Habbo;
import com.eu.habbo.habbohotel.users.HabboItem;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.generic.alerts.BubbleAlertComposer;
import com.eu.habbo.messages.outgoing.generic.alerts.BubbleAlertKeys;
import com.eu.habbo.messages.outgoing.rooms.items.FloorItemUpdateComposer;
import com.eu.habbo.messages.outgoing.rooms.users.RoomUserStatusComposer;
import com.eu.habbo.messages.outgoing.rooms.UpdateStackHeightComposer;
import com.eu.habbo.util.pathfinding.Tile;
import gnu.trove.set.hash.THashSet;

/**
 * Created on 20-9-2014 21:06.
 */
public class RotateMoveItemEvent extends MessageHandler {
    @Override
    public void handle() throws Exception {
        Room room = this.client.getHabbo().getHabboInfo().getCurrentRoom();

        if (room == null)
            return;

        if (this.client.getHabbo().getHabboInfo().getCurrentRoom().getOwnerId() != this.client.getHabbo().getHabboInfo().getId() && !this.client.getHabbo().hasPermission("acc_anyroomowner") && !this.client.getHabbo().hasPermission("acc_moverotate") && !room.hasRights(this.client.getHabbo()))
        {
            this.client.sendResponse(new BubbleAlertComposer(BubbleAlertKeys.FURNI_PLACE_EMENT_ERROR.key, "${room.error.cant_set_not_owner}"));
            return;
        }

        int furniId = this.packet.readInt();
        int x = this.packet.readInt();
        int y = this.packet.readInt();
        int rotation = this.packet.readInt();

        HabboItem item = room.getHabboItem(furniId);
        if (item == null)
            return;

        THashSet<Tile> updatedTiles = new THashSet<Tile>();

        if ((x != item.getX() || y != item.getY()) || item.getRotation() != rotation) {
            for (int i = item.getX(); i < item.getX() + item.getBaseItem().getWidth(); i++) {
                for (int j = item.getY(); j < item.getY() + item.getBaseItem().getLength(); j++) {
                    updatedTiles.add(new Tile(i, j, 0));
                }
            }
        }

        //room.removeHabboItem(item.getId());

        double checkStackHeight = item.getZ();
        if (x != item.getX() || y != item.getY() || item.getRotation() != rotation) {
            checkStackHeight = room.getStackHeight(x, y, false, item);
            for (int i = x; i < x + item.getBaseItem().getWidth(); i++) {
                for (int j = y; j < y + item.getBaseItem().getLength(); j++) {
                    double testheight = room.getStackHeight(i, j, false, item);
                    if (checkStackHeight != testheight && !(item instanceof InteractionStackHelper)) {
                        this.client.sendResponse(new BubbleAlertComposer(BubbleAlertKeys.FURNI_PLACE_EMENT_ERROR.key, "${room.error.cant_set_item}"));
                        this.client.sendResponse(new FloorItemUpdateComposer(item));
                        return;
                    }

                    if(room.getHabbosAt(i, j).size() > 0 && !item.getBaseItem().allowSit() && !(item instanceof InteractionStackHelper))
                    {
                        this.client.sendResponse(new BubbleAlertComposer(BubbleAlertKeys.FURNI_PLACE_EMENT_ERROR.key, "${room.error.cant_set_item}"));
                        this.client.sendResponse(new FloorItemUpdateComposer(item));
                        return;
                    }

                    Tile t = null;
                    for (Tile tile : updatedTiles) {
                        if (tile.X != i || tile.Y != j) {
                            t = new Tile(i, j, 0);
                        }
                    }
                    if (t != null)
                        updatedTiles.add(t);
                }
            }
        }

        int oldX = item.getX();
        int oldY = item.getY();

        if(item.getBaseItem().allowSit())
        {
            THashSet<Habbo> habbos = room.getHabbosAt(oldX, oldY);
            THashSet<RoomUnit> updatedUnits = new THashSet<RoomUnit>();
            for (Habbo habbo : habbos)
            {
                habbo.getRoomUnit().getStatus().remove("sit");
            }
            room.sendComposer(new RoomUserStatusComposer(updatedUnits, false).compose());
        }

        HabboItem hasStackHelper = room.getStackHelper(x, y);
        HabboItem topItem = null;
        if(hasStackHelper == null)
            topItem = room.getTopItemAt(x, y);

        if(topItem == null || (topItem != item && topItem.getBaseItem().allowStack())) {
            item.setZ(topItem == null && hasStackHelper != null ? hasStackHelper.getExtradata().isEmpty() ? Double.valueOf("0.0") : Integer.valueOf(hasStackHelper.getExtradata()) / 100 : checkStackHeight);
        }

        item.setX(x);
        item.setY(y);
        item.setRotation(rotation);
        //room.addHabboItem(item);
        room.sendComposer(new FloorItemUpdateComposer(item).compose());
        for(Tile t : updatedTiles)
        {
            t.Z = room.getStackHeight(t.X, t.Y, true);
        }
        room.updateTiles(updatedTiles);
        room.sendComposer(new UpdateStackHeightComposer(updatedTiles).compose());
        item.needsUpdate(true);
        Emulator.getThreading().run(item);
    }
}
