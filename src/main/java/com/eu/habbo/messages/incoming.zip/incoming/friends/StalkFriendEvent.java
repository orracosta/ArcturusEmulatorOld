package com.eu.habbo.messages.incoming.friends;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.users.Habbo;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.friends.StalkErrorComposer;

/**
 * Created on 4-11-2014 08:28.
 */
public class StalkFriendEvent extends MessageHandler
{
    @Override
    public void handle() throws Exception
    {
        int friendId = this.packet.readInt();

        Habbo habbo = Emulator.getGameEnvironment().getHabboManager().getHabbo(friendId);

        if(habbo == null)
        {
            this.client.sendResponse(new StalkErrorComposer(StalkErrorComposer.NOT_IN_FRIEND_LIST));
            return;
        }

        if(!habbo.isOnline())
        {
            this.client.sendResponse(new StalkErrorComposer(StalkErrorComposer.FRIEND_OFFLINE));
            return;
        }

        if(habbo.getHabboInfo().getCurrentRoom() == null)
        {
            this.client.sendResponse(new StalkErrorComposer(StalkErrorComposer.FRIEND_NOT_IN_ROOM));
            return;
        }

        if(habbo.getHabboStats().blockFollowing)
        {
            this.client.sendResponse(new StalkErrorComposer(StalkErrorComposer.FRIEND_BLOCKED_STALKING));
            return;
        }

        if(habbo.getHabboInfo().getCurrentRoom() != this.client.getHabbo().getHabboInfo().getCurrentRoom())
        {
            Emulator.getGameEnvironment().getRoomManager().enterRoom(this.client.getHabbo(), habbo.getHabboInfo().getCurrentRoom().getId(), "");
        }
    }
}
