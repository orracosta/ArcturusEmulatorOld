package com.eu.habbo.messages.incoming.handshake;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.users.Habbo;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.generic.alerts.GenericAlertComposer;
import com.eu.habbo.messages.outgoing.handshake.DebugConsoleComposer;
import com.eu.habbo.messages.outgoing.handshake.SecureLoginOKComposer;
import com.eu.habbo.messages.outgoing.hotelview.HotelViewComposer;
import com.eu.habbo.plugin.events.users.UserLoginEvent;

/**
 * Created on 24-8-2014 17:14.
 */
public class SecureLoginEvent extends MessageHandler {

    @Override
    public void handle() throws Exception {

        if(!Emulator.isReady)
            return;

        String sso = this.packet.readString();

        if(this.client.getHabbo() == null)
        {
            Habbo habbo = Emulator.getGameEnvironment().getHabboManager().loadHabbo(sso, this.client);
            if(habbo != null)
            {
                habbo.setClient(this.client);
                this.client.setHabbo(habbo);
                this.client.getHabbo().connect();
                this.client.sendResponse(new DebugConsoleComposer());
                this.client.sendResponse(new SecureLoginOKComposer());
                this.client.sendResponse(new HotelViewComposer());
                Emulator.getThreading().run(habbo);
                Emulator.getGameEnvironment().getHabboManager().addHabbo(habbo);
                Emulator.getPluginManager().fireEvent(new UserLoginEvent(habbo, this.client.getChannel().localAddress()));
            }
            else
            {
                this.client.sendResponse(new GenericAlertComposer("Your SSO ticket is invalid OR \r\nsomebody else is already logged in on your account!"));
                Emulator.getLogging().logUserLine("SSO not found! " + sso);
                Emulator.getServer().getGameClientManager().disposeClient(this.client.getChannel());
            }
        }
    }
}
