package com.eu.habbo.messages.incoming.rooms.items;

import com.eu.habbo.habbohotel.items.interactions.InteractionStackHelper;
import com.eu.habbo.habbohotel.users.HabboItem;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.rooms.UpdateStackHeightComposer;
import com.eu.habbo.messages.outgoing.rooms.items.FloorItemUpdateComposer;
import com.eu.habbo.util.pathfinding.Tile;
import gnu.trove.set.hash.THashSet;

/**
 * Created on 1-2-2015 21:19.
 */
public class SetStackHelperHeightEvent extends MessageHandler
{
    @Override
    public void handle() throws Exception
    {
        int itemId = this.packet.readInt();

        if(this.client.getHabbo().getHabboInfo().getCurrentRoom() == null)
            return;

        if(this.client.getHabbo().getHabboInfo().getId() == this.client.getHabbo().getHabboInfo().getCurrentRoom().getOwnerId() || this.client.getHabbo().getHabboInfo().getCurrentRoom().hasRights(this.client.getHabbo()))
        {
            HabboItem item = this.client.getHabbo().getHabboInfo().getCurrentRoom().getHabboItem(itemId);

            if(item instanceof InteractionStackHelper)
            {
                int height = this.packet.readInt();

                System.out.println(height);
                System.out.println(height / 100);

                item.setExtradata(height + "");
                this.client.getHabbo().getHabboInfo().getCurrentRoom().sendComposer(new FloorItemUpdateComposer(item).compose());

                THashSet<Tile> tiles = new THashSet<Tile>();
                tiles.add(new Tile(item.getX(), item.getY(), (height / 100) * 256.0D));
                this.client.getHabbo().getHabboInfo().getCurrentRoom().sendComposer(new UpdateStackHeightComposer(tiles).compose());
            }
        }
    }
}
