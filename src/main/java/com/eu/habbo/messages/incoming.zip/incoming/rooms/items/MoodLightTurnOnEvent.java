package com.eu.habbo.messages.incoming.rooms.items;

import com.eu.habbo.messages.incoming.MessageHandler;

/**
 * Created on 14-11-2014 20:31.
 */
public class MoodLightTurnOnEvent extends MessageHandler
{
    @Override
    public void handle() throws Exception
    {

    }
}
