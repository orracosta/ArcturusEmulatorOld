package com.eu.habbo.messages.incoming.hotelview;

import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.hotelview.NewsListComposer;

/**
 * Created on 27-8-2014 11:28.
 */
public class RequestNewsListEvent extends MessageHandler {

    @Override
    public void handle() throws Exception {
        this.client.sendResponse(new NewsListComposer());
    }
}
