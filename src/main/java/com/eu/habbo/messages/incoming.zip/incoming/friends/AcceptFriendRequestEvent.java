package com.eu.habbo.messages.incoming.friends;

import com.eu.habbo.messages.incoming.MessageHandler;

/**
 * Created on 25-8-2014 19:23.
 */
public class AcceptFriendRequestEvent extends MessageHandler {

    @Override
    public void handle() throws Exception {

        int count = this.packet.readInt();
        int userId;

        for(int i = 0; i < count; i++)
        {
            userId = this.packet.readInt();

            if(userId == 0)
                return;

            if(this.client.getHabbo().getMessenger().getFriends().containsKey(userId))
                continue;

            this.client.getHabbo().getMessenger().acceptFriendRequest(this.client.getHabbo().getHabboInfo().getId(), userId);
        }
    }
}
