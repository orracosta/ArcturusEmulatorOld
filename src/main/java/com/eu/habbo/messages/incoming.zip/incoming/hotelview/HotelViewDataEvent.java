package com.eu.habbo.messages.incoming.hotelview;

import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.hotelview.HotelViewDataComposer;

/**
 * Created on 27-8-2014 12:56.
 */
public class HotelViewDataEvent extends MessageHandler {

    @Override
    public void handle()
    {
        String hotelViewData = this.packet.readString();

        String[] data = hotelViewData.split(",");

        if(data.length > 1)
        {
            this.client.sendResponse(new HotelViewDataComposer(hotelViewData, data[data.length - 1]));
        }
        else
        {
            this.client.sendResponse(new HotelViewDataComposer("", ""));
        }
    }
}
