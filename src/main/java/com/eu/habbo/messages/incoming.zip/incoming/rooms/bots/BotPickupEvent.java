package com.eu.habbo.messages.incoming.rooms.bots;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.bots.Bot;
import com.eu.habbo.habbohotel.rooms.Room;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.inventory.AddBotComposer;
import com.eu.habbo.messages.outgoing.rooms.users.RoomUserRemoveComposer;

/**
 * Created on 15-10-2014 15:32.
 */
public class BotPickupEvent extends MessageHandler
{
    @Override
    public void handle() throws Exception
    {
        Room room = this.client.getHabbo().getHabboInfo().getCurrentRoom();

        if(room == null)
            return;

        if(room.getOwnerId() == this.client.getHabbo().getHabboInfo().getId() || this.client.getHabbo().hasPermission("acc_anyroomowner"))
        {
            if(!this.client.getHabbo().hasPermission("acc_unlimited_bots") && this.client.getHabbo().getHabboInventory().getBotsComponent().getUserBots().size() >= 15)
                return;

            int botId = this.packet.readInt();
            Bot bot = room.removeBot(Math.abs(botId));
            if(bot == null)
                return;

            room.sendComposer(new RoomUserRemoveComposer(bot.getRoomUnit()).compose());

            bot.setRoom(null);
            bot.setRoomUnit(null);
            bot.setOwnerId(this.client.getHabbo().getHabboInfo().getId());
            bot.setOwnerName(this.client.getHabbo().getHabboInfo().getUsername());
            bot.needsUpdate(true);
            Emulator.getThreading().run(bot);

            this.client.getHabbo().getHabboInventory().getBotsComponent().addBot(bot);
            this.client.sendResponse(new AddBotComposer(bot));
        }
    }
}
