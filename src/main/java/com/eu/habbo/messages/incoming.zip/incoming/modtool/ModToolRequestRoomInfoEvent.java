package com.eu.habbo.messages.incoming.modtool;

import com.eu.habbo.habbohotel.rooms.Room;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.modtool.ModToolRoomInfoComposer;

/**
 * Created on 4-11-2014 13:17.
 */
public class ModToolRequestRoomInfoEvent extends MessageHandler
{
    @Override
    public void handle() throws Exception
    {
        if(!this.client.getHabbo().hasPermission("acc_supporttool"))
            return;

        //int roomId = this.packet.readInt();

        Room room = this.client.getHabbo().getHabboInfo().getCurrentRoom();
        //Emulator.getGameEnvironment().getRoomManager().getRoom(roomId);

        if(room != null)
        {
            this.client.sendResponse(new ModToolRoomInfoComposer(room));
        }
    }
}
