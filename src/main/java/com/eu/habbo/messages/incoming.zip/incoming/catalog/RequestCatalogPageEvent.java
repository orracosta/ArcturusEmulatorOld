package com.eu.habbo.messages.incoming.catalog;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.catalog.CatalogPage;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.catalog.CatalogPageComposer;

/**
 * Created on 28-8-2014 11:51.
 */
public class RequestCatalogPageEvent extends MessageHandler {

    @Override
    public void handle() throws Exception {

        int catalogPageId = this.packet.readInt();

        CatalogPage page = Emulator.getGameEnvironment().getCatalogManager().catalogPages.get(catalogPageId);

        if(catalogPageId > 0 && page != null && page.getRank() <= this.client.getHabbo().getHabboInfo().getRank() && page.isEnabled())
        {
            this.client.sendResponse(new CatalogPageComposer(page));
        }
    }
}
