package com.eu.habbo.messages.incoming.rooms.bots;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.bots.Bot;
import com.eu.habbo.habbohotel.rooms.Room;
import com.eu.habbo.habbohotel.users.DanceType;
import com.eu.habbo.habbohotel.users.HabboGender;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.rooms.users.RoomUserDanceComposer;
import com.eu.habbo.messages.outgoing.rooms.users.RoomUsersComposer;
import com.eu.habbo.messages.outgoing.users.UserUpdateNameComposer;

/**
 * Created on 15-10-2014 16:07.
 */
public class BotSaveSettingsEvent extends MessageHandler
{
    @Override
    public void handle() throws Exception
    {
        Room room = this.client.getHabbo().getHabboInfo().getCurrentRoom();

        if(room == null)
            return;

        if(room.getOwnerId() == this.client.getHabbo().getHabboInfo().getId() || this.client.getHabbo().hasPermission("acc_anyroomowner"))
        {
            int botId = this.packet.readInt();

            Bot bot = room.getBot(Math.abs(botId));

            if(bot == null)
                return;

            int settingId = this.packet.readInt();

            switch(settingId)
            {
                case 1:
                    bot.setFigure(this.client.getHabbo().getHabboInfo().getLook());
                    bot.setGender(HabboGender.valueOf(this.client.getHabbo().getHabboInfo().getGender().name()));
                    bot.needsUpdate(true);
                    room.sendComposer(new RoomUsersComposer(bot).compose());
                    break;

                case 2:
                    String[] data = this.packet.readString().split(";#;");
                    bot.setChatAuto(Boolean.valueOf(data[data.length - 3]));
                    bot.setChatRandom(Boolean.valueOf(data[data.length - 1]));
                    bot.setChatDelay(Integer.valueOf(data[data.length - 2]));
                    bot.clearChat();
                    for(int i = 0; i < data.length - 3; i++)
                    {
                        bot.addChatLines(data[i].split("\r"));
                    }
                    bot.needsUpdate(true);
                    break;

                case 3:
                    bot.getRoomUnit().setCanWalk(!bot.getRoomUnit().canWalk());
                    bot.needsUpdate(true);
                    break;

                case 4:
                    if(bot.getRoomUnit().getDanceType().equals(DanceType.NONE))
                    {
                        bot.getRoomUnit().setDanceType(DanceType.HAB_HOP);
                    }else{
                        bot.getRoomUnit().setDanceType(DanceType.NONE);
                    }

                    room.sendComposer(new RoomUserDanceComposer(bot.getRoomUnit()).compose());
                    bot.needsUpdate(true);
                    break;

                case 5:
                    String name = this.packet.readString();
                    bot.setName(name);
                    bot.needsUpdate(true);
                    room.sendComposer(new UserUpdateNameComposer(bot.getRoomUnit(), bot.getName()).compose());
                    break;
            }

            if(bot.needsUpdate())
            {
                Emulator.getThreading().run(bot);
            }

        }
    }
}
