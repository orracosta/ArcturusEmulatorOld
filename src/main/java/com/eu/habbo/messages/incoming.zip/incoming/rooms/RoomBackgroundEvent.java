package com.eu.habbo.messages.incoming.rooms;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.rooms.Room;
import com.eu.habbo.habbohotel.users.HabboItem;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.rooms.items.FloorItemUpdateComposer;

/**
 * Created on 11-10-2014 22:11.
 */
public class RoomBackgroundEvent extends MessageHandler
{
    @Override
    public void handle() throws Exception
    {
        int itemId = this.packet.readInt();

        Room room = this.client.getHabbo().getHabboInfo().getCurrentRoom();
        if(room == null)
            return;

        if(room.getOwnerId() == this.client.getHabbo().getHabboInfo().getId() || this.client.getHabbo().hasPermission("acc_placefurni"))
        {
            HabboItem item = room.getHabboItem(itemId);

            if(item == null)
                return;

            int hue = this.packet.readInt();
            int saturation = this.packet.readInt();
            int light = this.packet.readInt();

            item.setExtradata(item.getExtradata().split(":")[0] + ":" + hue + ":" + saturation + ":" + light);
            item.needsUpdate(true);
            Emulator.getThreading().run(item);
            room.sendComposer(new FloorItemUpdateComposer(item).compose());
        }
    }
}
