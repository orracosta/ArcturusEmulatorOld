package com.eu.habbo.messages.incoming.rooms.users;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.commands.CommandHandler;
import com.eu.habbo.habbohotel.rooms.RoomChatMessage;
import com.eu.habbo.habbohotel.wired.WiredHandler;
import com.eu.habbo.habbohotel.wired.WiredTriggerType;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.rooms.RoomTalkComposer;

/**
 * Created on 13-9-2014 14:03.
 */
public class RoomUserTalkEvent extends MessageHandler {

    @Override
    public void handle() throws Exception
    {
        if(this.client.getHabbo().getHabboInfo().getCurrentRoom() == null)
            return;

        if(!this.client.getHabbo().getRoomUnit().canTalk())
            return;

        RoomChatMessage chatMessage = new RoomChatMessage(this);

        if(WiredHandler.handle(WiredTriggerType.SAY_SOMETHING, this.client.getHabbo().getRoomUnit(), this.client.getHabbo().getHabboInfo().getCurrentRoom(), new Object[]{chatMessage.getMessage()}))
        {
            return;
        }

        if (!CommandHandler.handleCommand(this.client, chatMessage.getMessage()))
        {
            if(this.client.getHabbo().getRoomUnit().talkTimeOut > 0 && (Emulator.getIntUnixTimestamp() - this.client.getHabbo().getRoomUnit().talkTimeOut < 0))
                return;

            this.client.getHabbo().getHabboInfo().getCurrentRoom().sendComposer(new RoomTalkComposer(chatMessage).compose());
            this.client.getHabbo().getRoomUnit().talkCounter++;
        }
    }
}
