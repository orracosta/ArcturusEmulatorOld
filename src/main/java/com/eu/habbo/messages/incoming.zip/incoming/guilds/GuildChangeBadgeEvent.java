package com.eu.habbo.messages.incoming.guilds;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.guilds.Guild;
import com.eu.habbo.messages.incoming.MessageHandler;

/**
 * Created on 23-11-2014 14:07.
 */
public class GuildChangeBadgeEvent extends MessageHandler
{
    @Override
    public void handle() throws Exception
    {
        int guildId = this.packet.readInt();

        Guild guild = Emulator.getGameEnvironment().getGuildManager().getGuild(guildId);

        if(guild.getOwnerId() == this.client.getHabbo().getHabboInfo().getId()) //TODO: Add staff support.
        {
            int count = this.packet.readInt() / 3;

            if(count < 3)
                return;

            int a = this.packet.readInt();
            int b = this.packet.readInt();
            int c = this.packet.readInt();

            String[] badgeData = new String[count];
            badgeData[0] = "b" + (a < 10 ? "0" + a : a) + (b < 10 ? "0" + b : b) + c;

            for (int i = 1; i < count; i++)
            {
                int j = this.packet.readInt();
                int k = this.packet.readInt();
                int l = this.packet.readInt();

                badgeData[i] = "s" + (j < 10 ? "0" + j : j) + (k < 10 ? "0" + k : k) + l;
            }

            String badge = "";
            for (int i = 0; i < badgeData.length; i++)
            {
                if (badgeData[i].equals("s000") || badgeData[i].equals("s00000"))
                {
                    badgeData[i] = "";
                }
                badge += badgeData[i];
            }

            if(guild.getBadge().toLowerCase().equals(badge.toLowerCase()))
                return;

            guild.setBadge(badge);
            guild.needsUpdate = true;
            Emulator.getThreading().run(guild);
        }

    }
}
