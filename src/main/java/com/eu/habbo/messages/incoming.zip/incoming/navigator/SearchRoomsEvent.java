package com.eu.habbo.messages.incoming.navigator;

import com.eu.habbo.Emulator;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.navigator.PrivateRoomsComposer;

/**
 * Created on 22-11-2014 10:08.
 */
public class SearchRoomsEvent extends MessageHandler
{
    @Override
    public void handle() throws Exception
    {
        String name = this.packet.readString();

        if(name.startsWith("owner:"))
        {
            name = name.split("owner:")[1];
            this.client.sendResponse(new PrivateRoomsComposer(Emulator.getGameEnvironment().getRoomManager().getRoomsForHabbo(name)));
        }
        else if(name.startsWith("tag:"))
        {
            name = name.split("tag:")[1];
            this.client.sendResponse(new PrivateRoomsComposer(Emulator.getGameEnvironment().getRoomManager().getRoomsWithTag(name)));
        }
        else if(name.startsWith("group:"))
        {
            name = name.split("group:")[1];
            this.client.sendResponse(new PrivateRoomsComposer(Emulator.getGameEnvironment().getRoomManager().getGroupRoomsWithName(name)));
        }
        else
        {
            this.client.sendResponse(new PrivateRoomsComposer(Emulator.getGameEnvironment().getRoomManager().getRoomsWithName(name)));
        }
    }
}
