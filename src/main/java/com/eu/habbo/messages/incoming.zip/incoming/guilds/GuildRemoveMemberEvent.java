package com.eu.habbo.messages.incoming.guilds;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.guilds.Guild;
import com.eu.habbo.habbohotel.rooms.Room;
import com.eu.habbo.habbohotel.rooms.RoomRightLevels;
import com.eu.habbo.habbohotel.users.Habbo;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.guilds.GuildInfoComposer;
import com.eu.habbo.messages.outgoing.guilds.GuildRefreshMembersListComposer;
import com.eu.habbo.messages.outgoing.rooms.RoomRightsComposer;

/**
 * Created on 23-11-2014 14:24.
 */
public class GuildRemoveMemberEvent extends MessageHandler
{
    @Override
    public void handle() throws Exception
    {
        int guildId = this.packet.readInt();
        int userId = this.packet.readInt();

        Guild guild = Emulator.getGameEnvironment().getGuildManager().getGuild(guildId);

        if (guild == null)
            return;

        if(guild.getOwnerId() == this.client.getHabbo().getHabboInfo().getId() && userId != this.client.getHabbo().getHabboInfo().getId())
        {
            Emulator.getGameEnvironment().getGuildManager().removeMember(guild, userId);

            this.client.sendResponse(new GuildRefreshMembersListComposer(guild));

            Habbo habbo = Emulator.getGameEnvironment().getHabboManager().getHabbo(userId);
            if (habbo != null)
            {
                habbo.getHabboStats().removeGuild(guild.getId());
                if (habbo.getHabboStats().guild == guildId)
                    habbo.getHabboStats().guild = 0;

                Room room = habbo.getHabboInfo().getCurrentRoom();
                if (room != null)
                {
                    if (room.getGuildId() == guildId)
                    {
                        habbo.getClient().sendResponse(new GuildInfoComposer(guild, habbo.getClient(), false, null));

                        boolean hasRights = room.hasRights(habbo);

                        habbo.getClient().sendResponse(new RoomRightsComposer(hasRights ? RoomRightLevels.RIGHTS.getLevel() : RoomRightLevels.NONE.getLevel()));

                        if(hasRights)
                            habbo.getRoomUnit().getStatus().put("flatctrl", RoomRightLevels.RIGHTS.getLevel() + "");
                        else
                            habbo.getRoomUnit().getStatus().remove("flatctrl");
                    }
                }
            }
        }
    }
}
