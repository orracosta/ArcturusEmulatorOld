package com.eu.habbo.messages.incoming.catalog.recycler;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.items.interactions.InteractionGift;
import com.eu.habbo.habbohotel.rooms.Room;
import com.eu.habbo.habbohotel.rooms.RoomChatMessage;
import com.eu.habbo.habbohotel.users.HabboItem;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.inventory.AddHabboItemComposer;
import com.eu.habbo.messages.outgoing.inventory.InventoryRefreshComposer;
import com.eu.habbo.messages.outgoing.rooms.items.FloorItemUpdateComposer;
import com.eu.habbo.messages.outgoing.rooms.items.PresentItemOpenedComposer;
import com.eu.habbo.messages.outgoing.rooms.items.RemoveFloorItemComposer;
import com.eu.habbo.messages.outgoing.rooms.users.RoomUserWhisperComposer;
import com.eu.habbo.threading.runnables.OpenGift;

/**
 * Created on 22-10-2014 12:03.
 */
public class OpenRecycleBoxEvent extends MessageHandler
{
    @Override
    public void handle() throws Exception
    {
        Room room = this.client.getHabbo().getHabboInfo().getCurrentRoom();

        if(room == null)
            return;

        if(room.getOwnerId() == this.client.getHabbo().getHabboInfo().getId() || this.client.getHabbo().hasPermission("acc_anyroomowner"))
        {
            HabboItem item = room.getHabboItem(this.packet.readInt());

            if(item == null)
                return;

            if(item instanceof InteractionGift)
            {
                ((InteractionGift) item).explode = true;
                room.sendComposer(new FloorItemUpdateComposer(item).compose());

                Emulator.getThreading().run(new OpenGift(item, this.client.getHabbo(), room), 1000);
            }
            else
            {
                if (item.getExtradata().length() == 0)
                {
                    this.client.sendResponse(new RoomUserWhisperComposer(new RoomChatMessage(Emulator.getTexts().getValue("error.recycler.box.empty"), this.client.getHabbo(), this.client.getHabbo(), 2)));
                } else
                {
                    HabboItem reward = Emulator.getGameEnvironment().getItemManager().handleOpenRecycleBox(this.client.getHabbo(), item);

                    if (reward != null)
                    {
                        this.client.getHabbo().getHabboInventory().getItemsComponent().addItem(reward);
                        this.client.sendResponse(new AddHabboItemComposer(reward));
                        this.client.sendResponse(new InventoryRefreshComposer());

                        this.client.sendResponse(new PresentItemOpenedComposer(reward, item.getExtradata(), true));
                    }
                }
                room.sendComposer(new RemoveFloorItemComposer(item).compose());
                room.removeHabboItem(item);

            }
        }
    }
}
