package com.eu.habbo.messages.incoming.rooms.users;

import com.eu.habbo.habbohotel.commands.CommandHandler;
import com.eu.habbo.habbohotel.rooms.RoomChatMessage;
import com.eu.habbo.habbohotel.wired.WiredHandler;
import com.eu.habbo.habbohotel.wired.WiredTriggerType;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.rooms.users.RoomUserShoutComposer;

/**
 * Created on 11-10-2014 16:07.
 */
public class RoomUserShoutEvent extends MessageHandler
{
    @Override
    public void handle() throws Exception
    {
        if(this.client.getHabbo().getHabboInfo().getCurrentRoom() == null)
            return;

        if(!this.client.getHabbo().getRoomUnit().canTalk())
            return;

        RoomChatMessage chatMessage = new RoomChatMessage(this);

        if(WiredHandler.handle(WiredTriggerType.SAY_SOMETHING, this.client.getHabbo().getRoomUnit(), this.client.getHabbo().getHabboInfo().getCurrentRoom(), new Object[]{chatMessage.getMessage()}))
        {
            return;
        }

        if (!CommandHandler.handleCommand(this.client, chatMessage.getMessage()))
        {
            //if(Emulator.getIntUnixTimestamp() - this.client.getHabbo().getRoomUnit().talkTimeOut > 0)
            //    return;

            this.client.getHabbo().getRoomUnit().talkCounter++;
            this.client.getHabbo().getHabboInfo().getCurrentRoom().sendComposer(new RoomUserShoutComposer(chatMessage).compose());
        }
    }
}
