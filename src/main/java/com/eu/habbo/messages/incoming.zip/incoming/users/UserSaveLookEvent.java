package com.eu.habbo.messages.incoming.users;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.achievements.AchievementManager;
import com.eu.habbo.habbohotel.users.HabboGender;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.users.UserDataComposer;
import com.eu.habbo.messages.outgoing.users.UserUpdateLookComposer;

/**
 * Created on 13-9-2014 19:47.
 */
public class UserSaveLookEvent extends MessageHandler {
    @Override
    public void handle() throws Exception {
        HabboGender gender = HabboGender.valueOf(this.packet.readString());
        String look = this.packet.readString();
        if(gender != null)
        {
            this.client.getHabbo().getHabboInfo().setLook(look);
            this.client.getHabbo().getHabboInfo().setGender(gender);
            Emulator.getThreading().run(this.client.getHabbo().getHabboInfo());
            if(this.client.getHabbo().getRoomUnit().isInRoom())
            {
                this.client.sendResponse(new UserDataComposer(this.client.getHabbo()));
                this.client.getHabbo().getHabboInfo().getCurrentRoom().sendComposer(new UserUpdateLookComposer(this.client.getHabbo()).compose());
            }
            else
            {
                this.client.sendResponse(new UserUpdateLookComposer(this.client.getHabbo()));
            }

            AchievementManager.progressAchievement(this.client.getHabbo(), Emulator.getGameEnvironment().getAchievementManager().achievements.get("AvatarLooks"));
        }
    }
}
