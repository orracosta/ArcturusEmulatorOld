package com.eu.habbo.messages.incoming.floorplaneditor;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.rooms.Room;
import com.eu.habbo.habbohotel.rooms.RoomLayout;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.generic.alerts.GenericAlertComposer;

/**
 * Created on 3-4-2015 21:39.
 */
public class FloorPlanEditorSaveEvent extends MessageHandler
{
    @Override
    public void handle() throws Exception
    {
        String map = this.packet.readString();
        int lengthX = -1;

        for(String s : map.split(((char)13) + ""))
        {
            if(lengthX == -1)
            {
                lengthX = s.length();
            }

            if(s.length() != lengthX)
            {
                this.client.sendResponse(new GenericAlertComposer("Incorrect Floorplan!"));
                return;
            }
        }

        map = map.substring(0, map.length()-1).replace((char)13 +"", "\r\n");

        int x = this.packet.readInt();
        int y = this.packet.readInt();
        int doorRotation = this.packet.readInt();
        int wallSize = this.packet.readInt();
        int floorSize = this.packet.readInt();
        int wallHeight = this.packet.readInt();

        System.out.println("X: " + x + ", Y: " + y + ", Door Rotation: " + doorRotation + ", WallSize: " + wallSize + ", FloorSize: " + floorSize + ", WallHeight: " + wallHeight);

        Room room = this.client.getHabbo().getHabboInfo().getCurrentRoom();

        if(room == null)
            return;

        if(room.getOwnerId() == this.client.getHabbo().getHabboInfo().getId() || this.client.getHabbo().hasPermission("acc_anyroomowner"))
        {
            RoomLayout layout = Emulator.getGameEnvironment().getRoomManager().getCustomLayout(room.getId());

            if(layout != null)
            {
                Emulator.getGameEnvironment().getRoomManager().insertCustomLayout(room.getId(), map, x, y, doorRotation);
                layout.setDoorX(x);
                layout.setDoorY(y);
                layout.setDoorDirection(doorRotation);
                layout.setMap(map);
                layout.parse();
            }
            else
            {
                layout = Emulator.getGameEnvironment().getRoomManager().insertCustomLayout(room.getId(), map, x, y, doorRotation);

            }

            if(layout != null)
            {
                room.setHasCustomLayout(true);
                room.setNeedsUpdate(true);
                room.setLayout(layout);
                room.sendComposer(new GenericAlertComposer("Floorplan has been edited!").compose());
                room.dispose();
            }
            else
            {
                this.client.sendResponse(new GenericAlertComposer("Saving Failed!"));
            }
        }
    }
}
