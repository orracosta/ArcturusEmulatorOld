package com.eu.habbo.messages.incoming.modtool;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.modtool.ModToolIssue;
import com.eu.habbo.habbohotel.users.Habbo;
import com.eu.habbo.messages.incoming.MessageHandler;

/**
 * Created on 5-3-2015 09:06.
 */
public class ModToolCloseTicketEvent extends MessageHandler
{

    @Override
    public void handle() throws Exception
    {
        int state = this.packet.readInt();
        int something = this.packet.readInt();
        int ticketId = this.packet.readInt();

        System.out.println(state + " - " + ticketId + " - " + something);

        ModToolIssue issue = Emulator.getGameEnvironment().getModToolManager().getTickets().get(ticketId);

        if(issue == null || issue.modId != this.client.getHabbo().getHabboInfo().getId())
            return;

        Habbo sender = Emulator.getGameEnvironment().getHabboManager().getHabbo(issue.senderId);

        switch (state)
        {
            case 1:
                Emulator.getGameEnvironment().getModToolManager().closeTicketAsUseless(issue, sender);
                break;

            case 2:
                Emulator.getGameEnvironment().getModToolManager().closeTicketAsAbusive(issue, sender);
                break;

            case 3:
                Emulator.getGameEnvironment().getModToolManager().closeTicketAsHandled(issue, sender);
                break;
        }
    }
}
