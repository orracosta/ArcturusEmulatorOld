package com.eu.habbo.messages.incoming.users;

import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.users.UserUpdateLookComposer;

/**
 * Created on 30-12-2014 12:25.
 */
public class SaveMottoEvent extends MessageHandler
{
    @Override
    public void handle() throws Exception
    {
        String motto = this.packet.readString();
        this.client.getHabbo().getHabboInfo().setMotto(motto);
        this.client.getHabbo().getHabboInfo().run();

        if(this.client.getHabbo().getHabboInfo().getCurrentRoom() != null)
        {
            this.client.getHabbo().getHabboInfo().getCurrentRoom().sendComposer(new UserUpdateLookComposer(this.client.getHabbo()).compose());
        }
        else
        {
            this.client.sendResponse(new UserUpdateLookComposer(this.client.getHabbo()));
        }
    }
}
