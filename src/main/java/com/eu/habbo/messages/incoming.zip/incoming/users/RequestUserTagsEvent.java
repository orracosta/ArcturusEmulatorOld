package com.eu.habbo.messages.incoming.users;

import com.eu.habbo.habbohotel.users.Habbo;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.users.UserTagsComposer;

/**
 * Created on 29-11-2014 09:57.
 */
public class RequestUserTagsEvent extends MessageHandler
{
    @Override
    public void handle() throws Exception
    {
        int userId = this.packet.readInt();

        if(this.client.getHabbo().getHabboInfo().getCurrentRoom() != null)
        {
            Habbo habbo = this.client.getHabbo().getHabboInfo().getCurrentRoom().getHabbo(userId);

            if(habbo != null)
            {
                this.client.sendResponse(new UserTagsComposer(habbo));
            }
        }
    }
}
