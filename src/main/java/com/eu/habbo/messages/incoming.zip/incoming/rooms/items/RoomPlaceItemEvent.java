package com.eu.habbo.messages.incoming.rooms.items;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.rooms.Room;
import com.eu.habbo.habbohotel.users.HabboItem;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.generic.alerts.BubbleAlertComposer;
import com.eu.habbo.messages.outgoing.generic.alerts.BubbleAlertKeys;
import com.eu.habbo.messages.outgoing.inventory.RemoveHabboItemComposer;
import com.eu.habbo.messages.outgoing.rooms.items.AddFloorItemComposer;
import com.eu.habbo.messages.outgoing.rooms.items.AddWallItemComposer;
import com.eu.habbo.messages.outgoing.rooms.UpdateStackHeightComposer;
import com.eu.habbo.util.pathfinding.Tile;
import gnu.trove.set.hash.THashSet;

/**
 * Created on 20-9-2014 19:35.
 */
public class RoomPlaceItemEvent extends MessageHandler {
    @Override
    public void handle() throws Exception {
        String[] values = this.packet.readString().split(" ");

        if(values.length < 1)
        {
            this.client.sendResponse(new BubbleAlertComposer(BubbleAlertKeys.FURNI_PLACE_EMENT_ERROR.key, "cant_set_item"));
            return;
        }

        if(!this.client.getHabbo().getRoomUnit().isInRoom() || (this.client.getHabbo().getHabboInfo().getCurrentRoom().getOwnerId() != this.client.getHabbo().getHabboInfo().getId() && !this.client.getHabbo().hasPermission("acc_anyroomowner") && !this.client.getHabbo().hasPermission("acc_placefurni")))
        {
            this.client.sendResponse(new BubbleAlertComposer(BubbleAlertKeys.FURNI_PLACE_EMENT_ERROR.key, "cant_set_not_owner"));
            return;
        }

        int itemId = Integer.valueOf(values[0]);
        if(itemId <= 0)
            return;

        HabboItem item = this.client.getHabbo().getHabboInventory().getItemsComponent().getHabboItem(itemId);

        if(item == null)
            return;

        Room room = this.client.getHabbo().getHabboInfo().getCurrentRoom();
        if(room.getId() != item.getRoomId() && item.getRoomId() != 0)
            return;

        THashSet<Tile> updatedTiles = new THashSet<Tile>();
        if(item.getBaseItem().getType().toLowerCase().equals("s")) {

            int x = Integer.valueOf(values[1]);
            int y = Integer.valueOf(values[2]);
            int rot = Integer.valueOf(values[3]);

            double checkStackHeight = room.getStackHeight(x, y, true);
            HabboItem stackHelper = room.getStackHelper(x, y);

            if(stackHelper == null)
            {
                for (int i = x; i < x + item.getBaseItem().getWidth(); i++)
                {
                    for (int j = y; j < y + item.getBaseItem().getLength(); j++)
                    {
                        double testheight = room.getStackHeight(i, j, true);
                        if (checkStackHeight != testheight)
                        {
                            this.client.sendResponse(new BubbleAlertComposer(BubbleAlertKeys.FURNI_PLACE_EMENT_ERROR.key, "${room.error.cant_set_item}"));
                            return;
                        }
                        if (room.getHabbosAt(i, j).size() > 0)
                        {
                            this.client.sendResponse(new BubbleAlertComposer(BubbleAlertKeys.FURNI_PLACE_EMENT_ERROR.key, "${room.error.cant_set_item}"));
                            return;
                        }
                        updatedTiles.add(new Tile(i, j, 0));
                    }
                }
            }

            item.setZ(stackHelper == null ? room.getStackHeight(x, y, false) : (stackHelper.getExtradata().isEmpty() ? 0.0D : Integer.valueOf(stackHelper.getExtradata()) / 100));
            item.setX(x);
            item.setY(y);
            item.setRotation(rot);
            room.sendComposer(new AddFloorItemComposer(item).compose());
            room.updateTiles(updatedTiles);
        }
        else
        {
            item.setWallPosition(values[1] + " " + values[2] + " " + values[3]);
            room.sendComposer(new AddWallItemComposer(item).compose());
        }

        this.client.sendResponse(new RemoveHabboItemComposer(item.getId()));
        item.needsUpdate(true);
        this.client.getHabbo().getHabboInventory().getItemsComponent().removeHabboItem(item.getId());
        room.addHabboItem(item);
        item.setRoomId(room.getId());

        for(Tile t : updatedTiles)
        {
            t.Z = room.getStackHeight(t.X, t.Y, true);
        }
        room.sendComposer(new UpdateStackHeightComposer(updatedTiles).compose());
        Emulator.getThreading().run(item);
        item.onPlace();
    }
}
