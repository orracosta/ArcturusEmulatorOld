package com.eu.habbo.messages.incoming.rooms.items;

import com.eu.habbo.habbohotel.rooms.Room;
import com.eu.habbo.habbohotel.users.HabboItem;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.generic.alerts.BubbleAlertComposer;
import com.eu.habbo.messages.outgoing.generic.alerts.BubbleAlertKeys;
import com.eu.habbo.messages.outgoing.rooms.items.FloorItemUpdateComposer;

/**
 * Created on 11-10-2014 13:59.
 */
public class MoveWallItemEvent extends MessageHandler
{
    @Override
    public void handle() throws Exception
    {
        Room room = this.client.getHabbo().getHabboInfo().getCurrentRoom();

        if(room == null)
            return;

        if(room.hasRights(this.client.getHabbo()) || this.client.getHabbo().hasPermission("acc_moverotate"))
        {
            int itemId = this.packet.readInt();
            String wallPosition = this.packet.readString();

            if(itemId <= 0 || wallPosition.length() <= 13)
                return;

            HabboItem item = room.getHabboItem(itemId);

            if(item == null)
                return;

            item.setWallPosition(wallPosition);
            room.sendComposer(new FloorItemUpdateComposer(item).compose());
        }
        else
        {
            this.client.sendResponse(new BubbleAlertComposer(BubbleAlertKeys.FURNI_PLACE_EMENT_ERROR.key, "${room.error.cant_set_not_owner}"));
        }
    }
}
