package com.eu.habbo.messages.incoming.catalog;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.bots.Bot;
import com.eu.habbo.habbohotel.catalog.CatalogItem;
import com.eu.habbo.habbohotel.catalog.CatalogPage;
import com.eu.habbo.habbohotel.items.Item;
import com.eu.habbo.habbohotel.items.interactions.*;
import com.eu.habbo.habbohotel.pets.Pet;
import com.eu.habbo.habbohotel.users.HabboItem;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.catalog.AlertLimitedSoldOutComposer;
import com.eu.habbo.messages.outgoing.catalog.AlertPurchaseFailedComposer;
import com.eu.habbo.messages.outgoing.catalog.PurchaseOKComposer;
import com.eu.habbo.messages.outgoing.generic.alerts.GenericAlertComposer;
import com.eu.habbo.messages.outgoing.inventory.AddBotComposer;
import com.eu.habbo.messages.outgoing.inventory.AddHabboItemComposer;
import com.eu.habbo.messages.outgoing.inventory.AddPetComposer;
import com.eu.habbo.messages.outgoing.inventory.InventoryRefreshComposer;
import com.eu.habbo.messages.outgoing.users.UserClubComposer;
import com.eu.habbo.messages.outgoing.users.UserCreditsComposer;
import com.eu.habbo.messages.outgoing.users.UserCurrencyComposer;
import com.eu.habbo.messages.outgoing.users.UserUpdateCurrencyComposer;
import gnu.trove.set.hash.THashSet;

import java.util.Calendar;

/**
 * Created on 29-8-2014 15:11.
 */
public class CatalogBuyItemEvent extends MessageHandler {

    @Override
    public void handle() throws Exception {

        int pageId = this.packet.readInt();
        int itemId = this.packet.readInt();
        String extraData = this.packet.readString();
        int count = this.packet.readInt();

        CatalogPage page = Emulator.getGameEnvironment().getCatalogManager().catalogPages.get(pageId);

        if(page == null)
        {
            CatalogItem item = Emulator.getGameEnvironment().getCatalogManager().getClubItem(itemId);

            if(item == null)
            {
                this.client.sendResponse(new AlertPurchaseFailedComposer(AlertPurchaseFailedComposer.SERVER_ERROR).compose());
                return;
            }

            int totalDays = 0;
            int totalCredits = 0;
            int totalDuckets = 0;

            for(int i = 0; i < count; i++)
            {
                String[] data = item.getName().split("_");

                if(data[2].equalsIgnoreCase("day"))
                {
                    totalDays = Integer.valueOf(data[3]);
                }
                else if(data[2].equalsIgnoreCase("month"))
                {
                    totalDays = Integer.valueOf(data[3]) * 31;
                }
                else if(data[2].equalsIgnoreCase("year"))
                {
                    totalDays = Integer.valueOf(data[3]) * 365;
                }

                totalCredits += item.getCredits();
                totalDuckets += item.getPoints();
            }

            if(totalDays > 0)
            {
                if (item.getPointsType() == 105)
                {
                    if (this.client.getHabbo().getHabboInfo().getPoints() < totalDuckets)
                        return;
                } else
                {
                    if (this.client.getHabbo().getHabboInfo().getPixels() < totalDuckets)
                        return;
                }

                if (this.client.getHabbo().getHabboInfo().getCredits() < totalCredits)
                    return;

                if (item.getPointsType() == 105)
                {
                    this.client.getHabbo().getHabboInfo().addPoints(-totalDuckets);
                } else
                {
                    this.client.getHabbo().getHabboInfo().addPixels(-totalDuckets);
                }

                this.client.getHabbo().getHabboInfo().addCredits(-totalCredits);

                this.client.getHabbo().getHabboStats().clubExpireTimestamp += totalDays * 86400;

                this.client.sendResponse(new UserClubComposer(this.client.getHabbo()));

                if (totalCredits > 0)
                    this.client.sendResponse(new UserCreditsComposer(this.client.getHabbo()));

                if (totalDuckets > 0)
                    this.client.sendResponse(new UserCurrencyComposer(this.client.getHabbo()));

                this.client.sendResponse(new PurchaseOKComposer(item, null));
                this.client.sendResponse(new InventoryRefreshComposer());
            }
            return;
        }

        CatalogItem item = page.getCatalogItem(itemId);
        Item cBaseItem = null;

        if(item == null)
        {
            this.client.sendResponse(new AlertPurchaseFailedComposer(AlertPurchaseFailedComposer.SERVER_ERROR).compose());
            return;
        }

        try
        {
            if (item.isLimited())
            {
                if (item.getLimitedSells() == item.getLimitedStack())
                {
                    this.client.sendResponse(new AlertLimitedSoldOutComposer());
                    return;
                }
                item.sellRare();
            }

            int totalCredits = 0;
            int totalPoints = 0;

            THashSet<HabboItem> itemsList = new THashSet<HabboItem>();

            for(int i = 0; i < count; i++)
            {
                if (item.getCredits() <= this.client.getHabbo().getHabboInfo().getCredits() - totalCredits)
                {
                    if(
                           item.getPointsType() == 0 && item.getPoints() <= this.client.getHabbo().getHabboInfo().getPixels() - totalPoints ||
                           item.getPoints() <= this.client.getHabbo().getHabboInfo().getPoints())
                    {
                        if ((i + 1) % 6 != 0 && item.isHaveOffer())
                        {
                            totalCredits += item.getCredits();
                            totalPoints += item.getPoints();
                        }

                        for (int j = 0; j < item.getAmount(); j++)
                        {
                            for (Item baseItem : item.getBaseItems())
                            {
                                for(int k = 0; k < item.getItemAmount(baseItem.getId()); k++)
                                {
                                    cBaseItem = baseItem;
                                    if (!baseItem.getName().contains("avatar_effect"))
                                    {
                                        if(item.getName().startsWith("rentable_bot_"))
                                        {
                                            Bot bot = Emulator.getGameEnvironment().getBotManager().createBot();
                                            bot.setOwnerId(this.client.getHabbo().getHabboInfo().getId());
                                            bot.setOwnerName(this.client.getHabbo().getHabboInfo().getUsername());
                                            bot.setFigure(item.getExtradata());
                                            bot.needsUpdate(true);
                                            Emulator.getThreading().run(bot);
                                            this.client.getHabbo().getHabboInventory().getBotsComponent().addBot(bot);
                                            this.client.sendResponse(new AddBotComposer(bot));
                                        }
                                        else if(Item.isPet(baseItem))
                                        {
                                            String[] data = extraData.split("\n");
                                            Pet pet = Emulator.getGameEnvironment().getPetManager().createPet(baseItem, data[0], data[1], data[2], this.client);
                                            this.client.getHabbo().getHabboInventory().getPetsComponent().addPet(pet);
                                            this.client.sendResponse(new AddPetComposer(pet));
                                        }
                                        else
                                        {
                                            if (baseItem.getInteractionType().getType() == InteractionTrophy.class || baseItem.getInteractionType().getType() == InteractionBadgeDisplay.class)
                                            {
                                                extraData = this.client.getHabbo().getHabboInfo().getUsername() + (char) 9 + Calendar.getInstance().get(Calendar.DAY_OF_MONTH) + "-" + (Calendar.getInstance().get(Calendar.MONTH) + 1) + "-" + Calendar.getInstance().get(Calendar.YEAR) + (char) 9 + extraData;
                                            }

                                            if (baseItem.getInteractionType().getType() == InteractionTeleport.class)
                                            {
                                                HabboItem teleportOne = Emulator.getGameEnvironment().getItemManager().createItem(this.client.getHabbo(), item, baseItem, extraData);
                                                HabboItem teleportTwo = Emulator.getGameEnvironment().getItemManager().createItem(this.client.getHabbo(), item, baseItem, extraData);
                                                Emulator.getGameEnvironment().getItemManager().insertTeleportPair(teleportOne.getId(), teleportTwo.getId());
                                                itemsList.add(teleportOne);
                                                itemsList.add(teleportTwo);
                                            }
                                            else if(baseItem.getInteractionType().getType() == InteractionHopper.class)
                                            {
                                                HabboItem hopper = Emulator.getGameEnvironment().getItemManager().createItem(0, baseItem, item.getLimitedSells(), item.getLimitedSells(), extraData);

                                                Emulator.getGameEnvironment().getItemManager().insertHopper(hopper);

                                                itemsList.add(hopper);
                                            }
                                            else if(baseItem.getInteractionType().getType() == InteractionGuildFurni.class || baseItem.getInteractionType().getType() == InteractionGuildGate.class)
                                            {
                                                InteractionGuildFurni habboItem = (InteractionGuildFurni)Emulator.getGameEnvironment().getItemManager().createItem(this.client.getHabbo(), item, baseItem, extraData);
                                                habboItem.setExtradata("");
                                                habboItem.needsUpdate(true);
                                                int guildId;
                                                try
                                                {
                                                   guildId = Integer.parseInt(extraData);
                                                }
                                                catch (Exception e)
                                                {
                                                    Emulator.getLogging().logErrorLine(e);
                                                    this.client.sendResponse(new AlertPurchaseFailedComposer(AlertPurchaseFailedComposer.SERVER_ERROR));
                                                    return;
                                                }
                                                Emulator.getThreading().run(habboItem);
                                                Emulator.getGameEnvironment().getGuildManager().setGuild(habboItem, guildId);
                                                itemsList.add(habboItem);
                                            }
                                            else
                                            {
                                                HabboItem habboItem = Emulator.getGameEnvironment().getItemManager().createItem(this.client.getHabbo(), item, baseItem, extraData);
                                                itemsList.add(habboItem);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        this.client.sendResponse(new GenericAlertComposer(Emulator.getTexts().getValue("error.catalog.buy.not_yet")));
                                        return;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if(!this.client.getHabbo().hasPermission("acc_infinite_credits"))
            {
                if (totalCredits > 0)
                {
                    this.client.getHabbo().getHabboInfo().addCredits(-totalCredits);
                    this.client.sendResponse(new UserCreditsComposer(this.client.getHabbo()));
                }
            }
            if(totalPoints > 0)
            {
                if(item.getPointsType() == 0 && !this.client.getHabbo().hasPermission("acc_infinite_pixels")) {
                    this.client.getHabbo().getHabboInfo().addPixels(-totalPoints);
                    this.client.sendResponse(new UserUpdateCurrencyComposer(this.client.getHabbo().getHabboInfo().getPixels(), -totalPoints, 0));
                }else if(item.getPointsType() == 105 && !this.client.getHabbo().hasPermission("acc_infinite_points")) {
                    this.client.getHabbo().getHabboInfo().addPoints(-totalPoints);
                    this.client.sendResponse(new UserUpdateCurrencyComposer(this.client.getHabbo().getHabboInfo().getPoints(), -totalPoints, 105));
                }
            }
            this.client.sendResponse(new AddHabboItemComposer(itemsList));
            this.client.getHabbo().getHabboInventory().getItemsComponent().addItems(itemsList);
            this.client.sendResponse(new PurchaseOKComposer(item, cBaseItem));
            this.client.sendResponse(new InventoryRefreshComposer());

        }
        catch(Exception e)
        {
            Emulator.getLogging().logPacketError(e);
            this.client.sendResponse(new AlertPurchaseFailedComposer(AlertPurchaseFailedComposer.SERVER_ERROR));
        }

    }
}
