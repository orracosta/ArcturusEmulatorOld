package com.eu.habbo.messages.incoming.rooms.bots;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.bots.Bot;
import com.eu.habbo.habbohotel.rooms.Room;
import com.eu.habbo.habbohotel.rooms.RoomUnit;
import com.eu.habbo.habbohotel.rooms.RoomUnitType;
import com.eu.habbo.habbohotel.rooms.RoomUserRotation;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.messages.outgoing.generic.alerts.BotErrorComposer;
import com.eu.habbo.messages.outgoing.generic.alerts.BubbleAlertComposer;
import com.eu.habbo.messages.outgoing.generic.alerts.BubbleAlertKeys;
import com.eu.habbo.messages.outgoing.inventory.RemoveBotComposer;
import com.eu.habbo.messages.outgoing.rooms.users.RoomUsersComposer;

/**
 * Created on 15-10-2014 12:23.
 */
public class BotPlaceEvent extends MessageHandler
{
    @Override
    public void handle() throws Exception
    {
        Room room = this.client.getHabbo().getHabboInfo().getCurrentRoom();

        if(room == null)
            return;

        if(room.getOwnerId() == this.client.getHabbo().getHabboInfo().getId() || this.client.getHabbo().hasPermission("acc_anyroomowner") || this.client.getHabbo().hasPermission("acc_placefurni"))
        {
            if(room.getCurrentBots().size() >= Emulator.getConfig().getInt("hotel.max.bots.room") && !this.client.getHabbo().hasPermission("acc_unlimited_bots"))
            {
                this.client.sendResponse(new BotErrorComposer(BotErrorComposer.ROOM_ERROR_MAX_BOTS));
                return;
            }

            int botId = this.packet.readInt();
            int x = this.packet.readInt();
            int y = this.packet.readInt();
            if(!room.tileWalkable(x, y))
                return;

            Bot bot = this.client.getHabbo().getHabboInventory().getBotsComponent().getBot(botId);

            if(bot == null)
                return;

            RoomUnit roomUnit = new RoomUnit();
            roomUnit.setRotation(RoomUserRotation.SOUTH);
            roomUnit.setX(x);
            roomUnit.setY(y);
            roomUnit.setZ(room.getStackHeight(x, y, false));
            roomUnit.setGoalLocation(x, y);
            roomUnit.setPathFinderRoom(room);
            roomUnit.setRoomUnitType(RoomUnitType.BOT);
            bot.setRoomUnit(roomUnit);
            bot.setRoom(room);
            bot.needsUpdate(true);
            room.addBot(bot);
            roomUnit.setId(room.getUnitCounter());
            Emulator.getThreading().run(bot);
            room.sendComposer(new RoomUsersComposer(bot).compose());
            this.client.getHabbo().getHabboInventory().getBotsComponent().removeBot(bot);
            this.client.sendResponse(new RemoveBotComposer(bot));
        }
        else
        {
            this.client.sendResponse(new BubbleAlertComposer(BubbleAlertKeys.FURNI_PLACE_EMENT_ERROR.key, "cant_set_not_owner"));
        }
    }
}
